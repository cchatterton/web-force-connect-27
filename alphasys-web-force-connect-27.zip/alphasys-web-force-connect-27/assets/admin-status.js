(() => {
	const bar = document.querySelector('.wfc27-heartbeat');
	if (!bar || typeof wfc27Status === 'undefined') return;
	const fill = bar.querySelector('.wfc27-heartbeat-fill');
	const label = document.getElementById('wfc27-heartbeat-label');
	const countdown = document.getElementById('wfc27-train-countdown');
	const stationWaiting = document.getElementById('wfc27-station-waiting');
	const tripRows = document.getElementById('wfc27-trip-rows');
	const tripFilter = document.getElementById('wfc27-trip-filter');
	const tripDay = document.getElementById('wfc27-trip-day');
	const tripHour = document.getElementById('wfc27-trip-hour');
	let last = bar.dataset.last ? Date.parse(bar.dataset.last) : NaN;
	let state = bar.dataset.state;

	function render() {
		if (state === 'paused') {
			fill.style.width = '0%';
			countdown.textContent = '—';
			label.textContent = 'Paused in Salesforce';
			bar.setAttribute('aria-valuenow', '0');
			return;
		}
		if (!Number.isFinite(last)) {
			fill.style.width = '0%';
			countdown.textContent = '01:00';
			label.textContent = 'Waiting for first train';
			bar.setAttribute('aria-valuenow', '0');
			return;
		}
		const elapsed = Math.max(0, Date.now() - last);
		const percent = Math.min(100, Math.floor(elapsed / 600));
		fill.style.width = `${percent}%`;
		bar.setAttribute('aria-valuenow', String(percent));
		if (elapsed >= 60000) {
			const overdue = Math.floor((elapsed - 60000) / 1000);
			countdown.textContent = `+${String(Math.floor(overdue / 60)).padStart(2, '0')}:${String(overdue % 60).padStart(2, '0')}`;
			label.textContent = 'Awaiting train';
		} else {
			const seconds = Math.ceil((60000 - elapsed) / 1000);
			countdown.textContent = seconds === 60 ? '01:00' : `00:${String(seconds).padStart(2, '0')}`;
			label.textContent = 'Running';
		}
	}

	async function refresh() {
		const data = new URLSearchParams({ action: 'wfc27_status', nonce: wfc27Status.nonce, trip_filter: tripFilter.value, trip_day: tripDay.value, trip_hour: tripHour.value });
		try {
			const response = await fetch(wfc27Status.url, { method: 'POST', credentials: 'same-origin', body: data, cache: 'no-store' });
			if (!response.ok) return;
			const result = await response.json();
			if (!result.success) return;
			last = result.data.last ? Date.parse(result.data.last) : NaN;
			state = result.data.state;
			stationWaiting.textContent = String(result.data.waiting);
			tripRows.replaceChildren();
			if (!result.data.trips.length) {
				const row = tripRows.insertRow();
				row.insertCell().colSpan = 3;
				row.cells[0].textContent = 'No syncs in this period.';
			} else {
				for (const trip of result.data.trips) {
					const row = tripRows.insertRow();
					const link = document.createElement('a');
					link.href = `${wfc27Status.syncUrl}${encodeURIComponent(trip.id)}`;
					link.textContent = trip.occurred_at;
					row.insertCell().appendChild(link);
					for (const value of [trip.sent_count, trip.received_count]) row.insertCell().textContent = String(value);
				}
			}
			render();
		} catch (_) { /* Keep the last known heartbeat visible. */ }
	}

	render();
	for (const control of [tripFilter, tripDay, tripHour]) control.addEventListener('change', refresh);
	refresh();
	window.setInterval(render, 250);
	window.setInterval(refresh, 10000);
})();
